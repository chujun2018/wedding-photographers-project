'use strict';

describe('myApp.homeView module', function() {

  beforeEach(module('myApp.homeView'));

  describe('homeView controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var homeViewCtrl = $controller('homeViewCtrl');
      expect(homeViewCtrl).toBeDefined();
    }));

  });
});