'use strict';

describe('myApp.photographerView module', function() {

  beforeEach(module('myApp.photographerView'));

  describe('photographerView controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var photographerViewCtrl = $controller('photographerViewCtrl');
      expect(photographerViewCtrl).toBeDefined();
    }));

  });
});