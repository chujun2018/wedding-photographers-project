'use strict';

describe('myApp.searchView module', function() {

  beforeEach(module('myApp.searchView'));

  describe('searchView controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var searchViewCtrl = $controller('searchViewCtrl');
      expect(searchViewCtrl).toBeDefined();
    }));

  });
});