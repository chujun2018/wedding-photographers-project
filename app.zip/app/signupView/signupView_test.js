'use strict';

describe('myApp.signupView module', function() {

  beforeEach(module('myApp.signupView'));

  describe('signupView controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var signupViewCtrl = $controller('signupViewCtrl');
      expect(signupViewCtrl).toBeDefined();
    }));

  });
});