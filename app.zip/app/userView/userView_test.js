'use strict';

describe('myApp.userView module', function() {

  beforeEach(module('myApp.userView'));

  describe('userView controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var userViewCtrl = $controller('userViewCtrl');
      expect(userViewCtrl).toBeDefined();
    }));

  });
});